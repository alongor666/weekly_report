#!/usr/bin/env bash
set -euo pipefail

OUT_DIR="reports"
SKILL_NAME="weekly_summary_v2"

mkdir -p "$OUT_DIR"

INPUT_JSON="data/week_44_skill_input.json"
if [ ! -f "$INPUT_JSON" ]; then
  echo "缺少输入：$INPUT_JSON"; exit 1
fi

OUT_PATH="${OUT_DIR}/weekly_summary_v2_w44.md"

cc run skill "${SKILL_NAME}"   --prompt ".claude/skills/${SKILL_NAME}/prompt.md"   --schema ".claude/skills/${SKILL_NAME}/schema.json"   --input  "${INPUT_JSON}"   --out    "${OUT_PATH}"

echo "✅ 已生成：${OUT_PATH}"
